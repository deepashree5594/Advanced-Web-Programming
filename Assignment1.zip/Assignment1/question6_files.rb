class Read_File
def read_input()
  puts "Sentences that start with Advisor : \n"

 # Open the input file in read mode
  File.open("input_file.txt","r") do |input|

 # Read the file line by line using gets
	while line = input.gets
	 # check if the sentence begins with advisor, if yes, then mark it true 
		if line.include?("ADVISOR:")
			advisor = true
		end
	 #  if advisor is  true, check if the sentence begins with Student, if, yes then mark advisor to false. This check will help in preventing  printing of the lines that strt with Student
		if advisor
			if line.include?("STUDENT:")
				advisor = false
			else
				puts "#{line}"
			end
		end
	end
   end
  end
end