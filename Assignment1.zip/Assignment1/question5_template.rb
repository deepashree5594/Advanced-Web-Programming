class Given_template
   @template
  def initialize(rhtml)
     @template = rhtml
  end
  def filter_template
  	# Remove the lines that start and end with <% and %> respectively and have anything in between this pattern and strip it to remove first newline char after gsub operation
    @template.gsub!(/<%(.)*%>/, "")
    # Since after the previous gsub, there will be too many newline chars in the file, remove them that occur more than once continously.
    @template.gsub!(/(\n)+/,"\n")
    # Substitute the line that starts with % with ""
    @template.sub!(/%/,"")
   return @template
end
end



