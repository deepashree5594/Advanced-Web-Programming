require 'sinatra'
require './database'

configure do
  enable :sessions
end


get '/login' do
  if session[:login]
    erb :play, :layout => false 
  else
    erb :loginform, :layout => false
  end
end


post '/play' do
  session[:money] =  params[:money]
  session[:bet]   =  params[:bet]
  session[:played] = true
  stake = session[:money].to_i
  number = session[:bet].to_i
  roll = rand(6) + 1

  
  if number == roll
    save_session(:win, stake)
    session[:current_total_win] = session[:win].to_i * 10
    session[:message_display] = "Dice landed on #{roll}, you won #{10*stake} dollars"
  else
    save_session(:lost, stake)
    session[:current_total_lost] = session[:lost]
    session[:message_display] = "Dice landed on #{roll}, you lost #{stake} dollars"
  end
   session[:current_total_profit] = session[:current_total_win].to_i - session[:current_total_lost].to_i
   redirect '/play'
end

def save_session(won_lost, money)
  count = (session[won_lost] || 0).to_i
  count += money
  session[won_lost] = count
end

get '/play' do
if session[:login]
 @player = Player.get(session[:name])
 session[:db_total_win] = @player.total_win
 session[:db_total_lost] = @player.total_lost
 session[:db_total_profit] = @player.total_profit
     if session[:played]
       erb :play, :layout => false
     else
       session[:current_total_lost] = 0
       session[:current_total_win] = 0
       session[:current_total_profit] = 0
       erb :play, :layout => false
     end
  else
     redirect '/login'
  end
end

post '/login' do
 @player = Player.get(params[:username])
 if @player 
  if @player.pwd == params[:password]
    session[:login] = true
    session[:name] = params[:username]
    redirect '/play'
  else
    session[:message] = "Username or Password does not match, please try again!"
    redirect '/login'
  end
 else
    session[:message] = "User does not exist, please enter a valid username!"
    redirect '/login'
 end 
end

get '/' do
  redirect '/login'
end

get '/logout' do
  @player = Player.get(session[:name])
  session[:login] = nil
  session[:name] = nil
  session[:message] = "You have sucessfully logged out, please login to play!"
  session[:db_win] =  session[:db_total_win] + session[:current_total_win]
  session[:db_lost] =  session[:db_total_lost] + session[:current_total_lost]
  session[:db_profit] = session[:db_total_profit] +session[:current_total_profit]

  currentwin = session[:current_total_win].to_i
  currentwin += @player.total_win
  @player.total_win = currentwin

  currentloss = session[:current_total_lost].to_i
  currentloss += @player.total_lost
  @player.total_lost = currentloss

  currentprofit = session[:current_total_profit].to_i
  currentprofit += @player.total_profit
  @player.total_profit = currentprofit

  @player.save

  session[:current_total_lost] = 0
  session[:current_total_win] = 0
  session[:current_total_profit] = 0

  redirect '/login'
end

not_found do
  "Unknown route"
end
