class WordOccurences

 def word_count(str = "", search_word = "")
 	# Check if string is empty
	if str.empty? 
	   puts "String is empty. Please provide a nonempty string"
       return
    end
    #  if search_word is not provided, print all the word count all all words
    if search_word.empty?
       words = str.split(" ")
       frequency = Hash.new(0)
       words.each do |word| 
          frequency[word]+=1
       end
       return frequency
    else
    	# search_word is  provided, print the frequency of that search_word
    	count = 0
    	words = str.split(" ")
    	words.each do |word|
    		if word == search_word
    			count += 1
            end
        end
        return count
    end
 end
end