class Compress
   def initialize(str)
      @str = str
      # Split the String into array of words with space as delimiter
      @words_array = str.split(" ")

      # Removeing duplicates using 'uniq' on array of words
      @uniqueWords_array = @words_array.uniq

      puts "Array of words of a string with no duplicates  : #{@uniqueWords_array} \n"

      # Using a hash to store the words as key and value as index at which they appear in the uniqueWords_array
      @compress_str = Hash.new()

       # Storing the words as key and value as index at which they appear in the uniqueWords_array
       @uniqueWords_array.each do |word|
       	  @compress_str[word] = @uniqueWords_array.index(word)
       end

       @index_array = []

       # Populate index array 
       @words_array.each do |word|
             @index_array.push(@compress_str[word])
       end      
		puts "Index to the original array to recover original string: #{@index_array}\n"
    end
 
    # menthod to get recover orignal string from index array and uniqueWords_array
    def recover_orignalString()
    	original_str = ""
    	@index_array.each do |index|
    		original_str += @uniqueWords_array[index]+" "
        end
        puts " Original String : #{original_str}"
    end
end

