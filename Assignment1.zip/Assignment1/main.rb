#!/usr/bin/ruby

#Question1
require_relative 'question1_WordCount.rb'

str = <<paragraph
Facebook and its founder must release documents and electronic correspondence to a defense lawyer
whose client has fled from criminal charges that he falsely claimed a majority ownership in the social
media giant, a federal judge said Friday.
paragraph

obj1 = WordOccurences.new()
ans1 = obj1.word_count(str)
puts "\n"
puts "The count of every word in given string is: \n#{ans1}"
puts "\n"
obj2 = WordOccurences.new()
ans2 = obj1.word_count(str, "and")
puts "The count of the word 'and' in given string is: \n#{ans2}"
puts "\n"

#Question2
require_relative 'question2_StudentSearch.rb'

student_records = [
{:firstname => "John", :lastname => "LastnameJohn", :phonenumber => 123456789},
{:firstname => "Ken", :lastname => "Lastnameken", :phonenumber => 456734244},
{:firstname => "Marisa", :lastname => "lastnamemarisa", :phonenumber => 443234567},
{:firstname => "Ken", :lastname => "Kenlastname", :phonenumber => 456734244}
]

student = Students.new()

student.search_students(student_records, firstname:"ken")
puts

student.search_students(student_records, lastname:"lastnamemarisa")
puts

student.search_students(student_records, phonenumber:123456789)
puts

#Question3
require_relative 'question3_CompressString.rb'

obj = Compress.new("I love you but do you love me")
obj.recover_orignalString();
puts
puts


#Question4
require_relative 'question4_hashMerge.rb'

h1 = { "a" => 100, "b" => 200 }
h2 = { "b" => 254, "c" => 300 }
puts "Result of h1.merge(h2) = \n#{h1.merge(h2)} \n"
puts "Value of h1 after h1.merge(h2) = \n#{h1} \n"

# h1.merge(h2){|key, val1, val2| val2 - val1}
puts "Result of h1.merge(h2){|key, val1, val2| val2 - val1} = \n#{h1.merge(h2){|key, val1, val2| val2 - val1}} \n "
puts "Value of h1 after h1.merge(h2){|key, val1, val2| val2 - val1} = \n#{h1} \n"


puts "Result of h1.merge!(h2) = \n#{h1.merge!(h2)} \n"
puts "Value of h1 after h1.merge!(h2) = \n#{h1} \n "

puts "Result of h1.merge!(h2){|key, val1, val2| val2 - val1} = \n#{h1.merge(h2){|key, val1, val2| val2 - val1}} \n"
puts "Value of h1 after h1.merge!(h2){|key, val1, val2| val2 - val1} = \n#{h1} \n"

#Question5
require_relative 'question5_template.rb'

rhtml = %{
<%= simple_form_for @project do |f| %>
<%= f.input :name %>
<%= f.input :description %>
<h3>Tasks</h3>
<div id='tasks'>
<%= f.simple_fields_for :tasks do |task| %>
<%= render 'task_fields', :f => task %>
<% end %>
<div class='links'>
<%= link_to_add_association 'add task', f, :tasks %>
</div>
</div>
<%= f.submit 'Save' %>
<% end %> %}

object1 = Given_template.new(rhtml)
puts "Filtered template : #{object1.filter_template}"

#Question6
require_relative 'question6_files.rb'

read_obj = Read_File.new()
puts  "#{read_obj.read_input}" 


