class Students

	def search_students(student_records, search_query)
		recordExists = false
		# if the input key matches :firstname then loop through the student records and comapre  student's firstname with the input value, if it matches then print that student's data and set the recordExists flag to true
		if search_query.keys[0] ==:firstname
         	student_records.each do |student|
			   if student[:firstname].casecmp(search_query.values[0]) == 0
			      recordExists = true
			      puts "#{student}\n"
		       end
		    end
		    # if the input key matches :lastname then loop through the student records and comapre  student's lastname with the input value, if it matches then print that student's data and set the recordExists flag to true
		elsif search_query.keys[0] ==:lastname
			student_records.each do |student| 
			   if student[:lastname].casecmp(search_query.values[0]) == 0
			      recordExists = true
			      puts "#{student}\n"
		       end
		    end
		   # if the input key matches :phonenumber then loop through the student records and comapre  student's phonenumber with the input value, if it matches then print that student's data and set the recordExists flag to true
		elsif search_query.keys[0] == :phonenumber
			student_records.each do |student|
			   if student[:phonenumber]== search_query.values[0]
			      recordExists = true
			      puts "#{student}\n"
		       end
		    end
		end
	   # after looping through all the student records, if no record matches with the given input, then print " No match found"
        if recordExists == false
          puts "No match found"
        end
	end
end
