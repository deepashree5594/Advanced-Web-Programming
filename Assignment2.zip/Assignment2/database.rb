require 'dm-core'
require 'dm-migrations'

configure :development do
   DataMapper.setup(:default, "sqlite3://#{Dir.pwd}/main.db")
end

configure :production do
    DataMapper.setup(:default, ENV['DATABASE_URL'])
end

class Player
  include DataMapper::Resource
  property :user, String, key: true
  property :pwd, String
  property :total_win, Integer
  property :total_lost, Integer
  property :total_profit, Integer
end

DataMapper.finalize

