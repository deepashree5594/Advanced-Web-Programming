class Hash
	def merge(second_hash)
		# to copy the object but not object attributes
		res = self.dup
		second_hash.each do |k, v|
			# checking if block is available if, yes use yield that returnns true
			if block_given? and self.key?(k)
				# using yield because we are dealing with block
				res[k] = yield(k, res[k], v) 
			else
				# if there is no block then simply merge ( overwrite with second hash's value if there is a duplicate key
				res[k] = v
			end
		end
		return res
	end
	def merge!(second_hash)
		second_hash.each do |k, v|
			# checking if block is available if, yes use yield that returnns true
			if block_given? and self.key?(k)
				# if there is no block then overwrite with self[k] in case of duplicate key
				self[k] = yield(k, self[k], v)
			else
				# assign value v to slef[k] if block is unavialable.
				self[k] = v
			end
		end
		# return self
		return self
	end
end